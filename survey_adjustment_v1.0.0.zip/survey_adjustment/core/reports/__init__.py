"""Report generation helpers (QGIS-free)."""

from .html_report import render_html_report, save_html_report

__all__ = ["render_html_report", "save_html_report"]
