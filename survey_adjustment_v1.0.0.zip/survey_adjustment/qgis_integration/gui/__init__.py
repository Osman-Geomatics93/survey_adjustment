"""
QGIS GUI components for survey adjustment.

This module will contain dialog and widget implementations (Phase 3+).
"""

# Phase 3+ implementation
