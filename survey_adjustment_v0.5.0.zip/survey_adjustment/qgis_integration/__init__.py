"""
QGIS integration module for survey adjustment.

This module provides the QGIS plugin interface (Phase 3+).
"""

# Phase 3+ implementation
